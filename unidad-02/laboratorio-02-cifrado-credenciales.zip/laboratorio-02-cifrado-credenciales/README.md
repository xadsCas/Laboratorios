# Laboratorio 02 — Cifrado y credenciales

## Objetivo

## Comando o procedimiento

## Resultado obtenido

## Análisis

## Conclusión