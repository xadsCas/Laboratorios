¿Qué ocurriría si alguien obtiene acceso de lectura a esta tabla?



¿Por qué es inseguro almacenar contraseñas en texto claro?