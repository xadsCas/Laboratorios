Situación	Mecanismo apropiado	¿Qué protege?
Contraseña de usuario	Hash de contraseña	Evita almacenar la contraseña original
RFC almacenado en una tabla	Cifrado, cuando esté justificado	Protege el dato almacenado
Consulta enviada al servidor	TLS	Protege la comunicación
Respaldo de base de datos	Cifrado del respaldo	Protege la copia almacenada
Clave criptográfica	Gestión segura de claves	Evita accesos y exposiciones no autorizadas