¿Cuál es la diferencia entre crypt() y pgp_sym_encrypt()?



¿Cuál permite recuperar el dato original?



¿Qué ocurre si se utiliza una clave incorrecta?



¿Por qué es peligroso escribir una clave directamente en una consulta?