¿Cuáles son los principales riesgos?



¿Qué mecanismo utilizarías para proteger cada elemento?



¿Cuál problema consideras más crítico y por qué?



¿Tener correctamente configurados los usuarios y permisos elimina estos riesgos? Justifica tu respuesta.