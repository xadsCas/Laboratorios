SHOW ssl;

![alt text](image.png)

SHOW ssl_min_protocol_version;

![alt text](image-1.png)

SHOW port;

![alt text](image-2.png)

SHOW listen_addresses;

![alt text](image-3.png)

SELECT
    inet_client_addr(),
    inet_client_port();

![alt text](image-4.png)

SELECT
    ssl,
    version,
    cipher
FROM pg_stat_ssl
WHERE pid = pg_backend_pid();

![alt text](image-5.png)

¿La conexión actual utiliza TLS?
¿Qué versión de TLS se está utilizando?
¿Qué algoritmo de cifrado aparece?
¿Qué diferencia existe entre una conexión protegida con TLS y una conexión sin TLS?




en psql:

SELECT
    ssl,
    version,
    cipher
FROM pg_stat_ssl
WHERE pid = pg_backend_pid();

![alt text](image-6.png)
