-- LAB-01: Enmascaramiento de datos
-- Incluye el rol de soporte, la vista con datos enmascarados y permisos.

--creamos rol de soporte
CREATE ROLE soporte NOLOGIN;

--creamos vista con el acceso restringido 
CREATE VIEW v_clientes_soporte AS
SELECT
    id,
    nombre,

    CONCAT(
        LEFT(correo, 2),
        '*****',
        SUBSTRING(correo FROM POSITION('@' IN correo))
    ) AS correo,

    CONCAT(
        '******',
        RIGHT(telefono, 4)
    ) AS telefono,

    CONCAT(
        '*********',
        RIGHT(rfc, 4)
    ) AS rfc

FROM clientes;

--Verificamos vista
SELECT *
FROM v_clientes_soporte;

--Damos acceso a la vista 
GRANT USAGE
ON SCHEMA public
TO soporte;

GRANT SELECT
ON v_clientes_soporte
TO soporte;

--Quitamos acceso a la vista buena
REVOKE ALL
ON clientes
FROM soporte;

--verificamos ambas vistas
SELECT *
FROM v_clientes_soporte;

SELECT *
FROM clientes;
