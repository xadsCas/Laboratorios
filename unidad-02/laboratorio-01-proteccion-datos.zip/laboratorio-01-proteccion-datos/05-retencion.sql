-- LAB-01: Retención de datos
-- Consulta los registros con fecha de alta anterior a cinco años.

SELECT *
FROM clientes
WHERE fecha_alta <
      CURRENT_DATE - INTERVAL '5 years';
