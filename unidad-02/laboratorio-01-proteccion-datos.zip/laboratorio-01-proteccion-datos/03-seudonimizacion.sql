-- LAB-01: Seudonimización y control de acceso
-- Incluye los esquemas, el mapa de tokens, la tabla analítica y el rol analista.

--Esquemas insanos
CREATE SCHEMA pii;

CREATE SCHEMA analitica;

--tabla para el esquema 
CREATE TABLE pii.mapa_cliente (
    token UUID PRIMARY KEY,
    cliente_id BIGINT UNIQUE
        REFERENCES public.clientes(id)
);

--extension 
CREATE EXTENSION IF NOT EXISTS pgcrypto;

--token x cliente 
INSERT INTO pii.mapa_cliente
(token, cliente_id)
SELECT
    gen_random_uuid(),
    id
FROM clientes;

--verificar como todas las veces anteriores 
SELECT *
FROM pii.mapa_cliente;

--crear tabla para el conjunto de analitica

CREATE TABLE analitica.clientes AS
SELECT
    m.token AS cliente_token,
    c.edad,
    c.ciudad,
    c.codigo_postal,
    c.fecha_alta
FROM pii.mapa_cliente m
JOIN clientes c
    ON c.id = m.cliente_id;

--verificar...
SELECT *
FROM analitica.clientes;

--rol analista
CREATE ROLE analista NOLOGIN;

--dar acceso a la tabla para analista
GRANT USAGE
ON SCHEMA analitica
TO analista;

GRANT SELECT
ON analitica.clientes
TO analista;

--verificar...
SELECT *
FROM analitica.clientes;

SELECT *
FROM pii.mapa_cliente;

SELECT *
FROM public.clientes;
