Problema	Principio afectado	Riesgo	Control propuesto
Analítica accede a toda la tabla	Minimización	Exposición innecesaria	Vista con datos agregados
Copias reales en desarrollo	Privacidad y confidencialidad	Filtración de datos	Datos sintéticos o anonimizados
Conservación durante 12 años sin política	Retención	Acumulación de información innecesaria	Política justificada
Marketing utiliza correos sin finalidad documentada	Limitación de finalidad	Uso no autorizado o incompatible	Evaluación previa y controles
No existe matriz de responsabilidades	Gobierno de datos	Falta de rendición de cuentas	Asignar responsables