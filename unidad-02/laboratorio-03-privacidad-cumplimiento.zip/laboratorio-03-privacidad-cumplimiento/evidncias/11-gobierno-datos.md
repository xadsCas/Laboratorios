Dato	Responsable	Usuarios autorizados	Protección
Nombre	Atención al cliente	Soporte y facturación, según necesidad	Acceso por roles
Correo	Responsable del área de clientes	Soporte; marketing solo si procede	Acceso limitado
Teléfono	Responsable del área de clientes	Soporte	Acceso limitado
RFC	Facturación	Personal autorizado de facturación	Acceso restringido
Edad	Responsable de analítica	Analítica mediante rangos	Minimización
Ciudad	Responsable de analítica	Analítica con finalidad definida	Vista limitada
Código postal	Responsable de clientes	Solo áreas que lo necesiten	Acceso limitado