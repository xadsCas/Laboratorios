¿Es compatible con la minimización?



¿Qué riesgos genera conservar información innecesaria?



¿Qué debe determinarse antes de establecer un periodo?



¿Qué información debe documentarse para justificar ese periodo?