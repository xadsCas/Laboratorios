¿Qué problemas identificas?



¿Qué principio de privacidad se ignora?



¿Qué preguntas harías antes de aprobar el diseño?



¿Qué datos eliminarías de la estructura propuesta?



¿Qué datos necesitarían justificación adicional?



¿Cómo aplicarías privacidad por defecto?