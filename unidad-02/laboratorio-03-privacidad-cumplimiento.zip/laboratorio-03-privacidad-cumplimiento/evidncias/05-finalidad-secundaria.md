![alt text](image-1.png)


![alt text](image-2.png)

¿Tener los datos significa que la empresa puede utilizarlos para cualquier finalidad?



¿Qué debe comprobar la organización antes de implementar el nuevo uso?



¿Qué datos son realmente necesarios para las promociones?



¿Marketing necesita acceso directo a clientes?



¿Qué controles técnicos podrían limitar la información?