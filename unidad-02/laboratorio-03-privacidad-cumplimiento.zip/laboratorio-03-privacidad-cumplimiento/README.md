# Laboratorio 03 — Privacidad y cumplimiento
Introducción.



Inventario de datos.



Finalidades.



Minimización.



Control de acceso.



Derechos ARCO.



Retención.



Gobierno de datos.



Evaluación integral.



Conclusiones.